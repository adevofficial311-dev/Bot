# Yama Discord Bot — Hosting Guide (Vercel + 24/7 Bot Runner)

## ⚠️ Important Note on 24/7 Bot Uptime & Vercel
**Vercel** is a **serverless** platform designed for web apps and APIs. When you close your web browser or when there is no web traffic, Vercel puts its serverless functions to sleep. Therefore, **Vercel cannot maintain a 24/7 continuous Discord WebSocket connection (`discord.js` gateway)** by itself.

To run your bot **24/7** while using this Web Dashboard to manage settings, logs, and tokens:
1. **Host the Web UI on Vercel**: Use the downloaded ZIP to host your gorgeous web control center on Vercel.
2. **Host the 24/7 Bot Worker on Railway, Render, or a VPS**: 
   - Deploy the same ZIP package or repository to a free/low-cost 24/7 cloud host like **Railway.app** or **Render.com**.
   - Set the Start Command to: `npm run bot` (which runs `bot.ts`).
   - Add your environment variables: `DISCORD_TOKEN`, `OPENROUTER_API_KEY`, and upload your `firebase-applet-config.json`.
   - Your bot will stay online 24/7, while your Vercel web dashboard lets you monitor logs and update settings in real time via Firestore!

---

## 🚀 1-Click ZIP Deployment to Vercel

1. Download the generated ZIP file (`yama-discord-bot-vercel.zip`) from the **Vercel Deploy** tab.
2. Go to [vercel.com/new](https://vercel.com/new) and upload or drag-and-drop the ZIP archive.
3. In **Project Settings > Environment Variables**, add your secrets:
   - `DISCORD_TOKEN`: Your bot token from the Discord Developer Portal.
   - `OPENROUTER_API_KEY`: Your OpenRouter AI key.
4. Click **Deploy**.

---

## 📁 Pre-Configured Architecture
- **`src/App.tsx`**: Lightweight, high-performance web control center.
- **`api/`**: Serverless API routes for Vercel.
- **`bot.ts`**: Standalone 24/7 Discord bot runner with Firebase Firestore sync.
